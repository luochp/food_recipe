from recipe_scrapers.tests.test_allrecipes import *
from recipe_scrapers.tests.test_bbcfood import *
from recipe_scrapers.tests.test_bbcgoodfood import *
from recipe_scrapers.tests.test_bonappetit import *
from recipe_scrapers.tests.test_closetcooking import *
from recipe_scrapers.tests.test_cookstr import *
from recipe_scrapers.tests.test_epicurious import *
from recipe_scrapers.tests.test_finedininglovers import *
from recipe_scrapers.tests.test_foodrepublic import *
from recipe_scrapers.tests.test_hundredandonecookbooks import *
from recipe_scrapers.tests.test_jamieoliver import *
from recipe_scrapers.tests.test_mybakingaddiction import *
from recipe_scrapers.tests.test_paninihappy import *
from recipe_scrapers.tests.test_realsimple import *
from recipe_scrapers.tests.test_simplyrecipes import *
from recipe_scrapers.tests.test_steamykitchen import *
from recipe_scrapers.tests.test_tastykitchen import *
from recipe_scrapers.tests.test_thepioneerwoman import *
from recipe_scrapers.tests.test_thevintagemixer import *
from recipe_scrapers.tests.test_twopeasandtheirpod import *
from recipe_scrapers.tests.test_whatsgabycooking import *


import unittest


if __name__ == '__main__':
    unittest.main()
