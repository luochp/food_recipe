#!/bin/bash

python src/get_recipes.py --ar --sleep 200